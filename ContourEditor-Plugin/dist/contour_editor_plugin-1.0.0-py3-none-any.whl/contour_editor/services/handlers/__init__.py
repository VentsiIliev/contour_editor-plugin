# Workpiece-specific handlers have been moved to workpiece_editor package
# This module is kept for backward compatibility but is now empty

__all__ = []
