# Redirect to new location
from ...ui.new_widgets.point_manager.models import *
