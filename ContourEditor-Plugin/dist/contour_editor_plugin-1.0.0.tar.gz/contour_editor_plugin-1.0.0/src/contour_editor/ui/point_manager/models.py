# Redirect to new location
from ...ui.widgets.point_manager.models import *
