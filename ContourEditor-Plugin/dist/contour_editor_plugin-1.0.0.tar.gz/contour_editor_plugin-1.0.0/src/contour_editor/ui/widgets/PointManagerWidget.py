"""Backward-compatibility shim. Import from .point_manager instead."""
from .point_manager import PointManagerWidget

__all__ = ["PointManagerWidget"]
