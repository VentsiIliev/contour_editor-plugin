"""
Contour Editor Model Package

Application-agnostic data models for the contour editor.
"""

__all__ = []

