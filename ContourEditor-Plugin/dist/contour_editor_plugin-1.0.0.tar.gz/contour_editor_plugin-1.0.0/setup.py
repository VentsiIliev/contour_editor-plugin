#!/usr/bin/env python3
"""Setup script for contour-editor-plugin"""
from setuptools import setup

# Configuration is in pyproject.toml
setup()

